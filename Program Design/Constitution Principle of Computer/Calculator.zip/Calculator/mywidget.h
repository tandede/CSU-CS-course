#ifndef MYWIDGET_H      //避免重复定义
#define MYWIDGET_H

#include <QWidget>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class myWidget; }
QT_END_NAMESPACE

typedef  struct BiTNode
{
    QChar data;
    QString combine_data;
    BiTNode *lchild,*rchild;

}*BiTree;

//定义一种栈方便同时储存二叉树结点和符号
typedef struct StackNode
{
    BiTree data_tree;	//存储的是二叉树
    QChar data_op;	//存储的是符号
    StackNode *next;
}*LinkStack;




class myWidget : public QWidget
{
    Q_OBJECT

public:
    myWidget(QWidget *parent = nullptr);
    ~myWidget();

    double Do();//将表达式字符串计算并return出结果

    bool   is_num(char S);//判断是否为数字

    double Cal(double a,char b,double c);//进行局部运算

    int    prior(char c);//先将字符优先级数字化便于比较优先级

    int    prior_cmp(char opt1,char opt2);//比较两字符的优先级

    void on_actionRight_triggered();//输出右对齐

    //构造栈的函数
    int InitStack(LinkStack &S);//栈的初始化
    int Push_tree(LinkStack &S, BiTree e);//二叉树入栈
    int Push_op(LinkStack &S, QChar e);//字符（运算符号）入栈
    int Pop_tree(LinkStack &S, BiTree &T1);//二叉树出栈
    int Pop_op(LinkStack &S, QChar &ch);//字符（运算符号）出栈
    QChar GetTop_op(LinkStack S);//取栈顶元素
    BiTree GetTop_tree(LinkStack S);//取栈顶元素

    //创建二叉树
    void CreateExpTree(BiTree &T, BiTree a, BiTree b, QChar theta);//a是左孩子，b是右孩子,theta是数据域
    void CreateExpTree_str(BiTree &T, BiTree a, BiTree b, QString theta);

    //比较运算符的优先级
    //top是栈顶元素，ch是需要比较的元素
    char Precede(QChar top, QChar ch);

    //创建表达式树
    //expt栈(根结点)，optr栈(运算符)
    void InitExpTree(LinkStack &expt, LinkStack &optr);

    //树的遍历
    void PreOrder(BiTree T);
    void InOrder(BiTree T);
    void PostOrder(BiTree T);







private slots:

     //编写槽函数,和按钮进行匹配
     void pushButton0();
     void pushButton1();
     void pushButton2();
     void pushButton3();
     void pushButton4();
     void pushButton5();
     void pushButton6();
     void pushButton7();
     void pushButton8();
     void pushButton9();
     void pushButton_add();
     void pushButton_sub();
     void pushButton_mul();
     void pushButton_div();
     void pushButton_equ();
     void pushButton_low_l();
     void pushButton_low_r();
     void pushButton_mid_l();
     void pushButton_mid_r();
     void pushButton_turn_off();
     void pushButton_AC();
     void pushButton_Del();

     void pushButton_Pre();
     void pushButton_In();
     void pushButton_Post();

     //报错函数
     void operror1(int num=1);

     int  bracket_error1();
     int  bracket_error2();
     void bracket_digit_error1();
     void bracket_digit_error2();
     void digit_bracket_error1();
     void digit_bracket_error2();

     //显示时间的函数
     void timerUpdate(void);




private:
    Ui::myWidget *ui;

    QString str;//创建一个类为QString的对象，用来存储运算字符串
    BiTree  T=NULL;//树的根节点





};
#endif // MYWIDGET_H
