#include "mywidget.h"
#include "ui_mywidget.h"
#include <QTimer>
#include <QDateTime>
#include <QMessageBox>
#include <QStack>

myWidget::myWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::myWidget)
{
    ui->setupUi(this);

    //修改按钮的字体和大小
    ui->pushButton0->setFont(QFont("宋体", 18));
    ui->pushButton1->setFont(QFont("宋体", 18));
    ui->pushButton2->setFont(QFont("宋体", 18));
    ui->pushButton3->setFont(QFont("宋体", 18));
    ui->pushButton4->setFont(QFont("宋体", 18));
    ui->pushButton5->setFont(QFont("宋体", 18));
    ui->pushButton6->setFont(QFont("宋体", 18));
    ui->pushButton7->setFont(QFont("宋体", 18));
    ui->pushButton8->setFont(QFont("宋体", 18));
    ui->pushButton9->setFont(QFont("宋体", 18));
    ui->pushButton_add->setFont(QFont("宋体", 18));
    ui->pushButton_sub->setFont(QFont("宋体", 18));
    ui->pushButton_div->setFont(QFont("宋体", 18));
    ui->pushButton_mul->setFont(QFont("宋体", 18));
    ui->pushButton_equ->setFont(QFont("宋体", 18));
    ui->pushButton_low_l->setFont(QFont("宋体", 18));
    ui->pushButton_low_r->setFont(QFont("宋体", 18));
    ui->pushButton_mid_l->setFont(QFont("宋体", 18));
    ui->pushButton_mid_r->setFont(QFont("宋体", 18));
    ui->pushButton_turn_off->setFont(QFont("宋体", 14));


    //修改输入输出时显示在textEdit框里数字的大小和格式
    QFont textEditFont ( "Microsoft YaHei", 25, 75);
    ui->textEdit->setFont(textEditFont);


    //修改窗口
    setWindowTitle("Txy's Calculator");

    //将将textEdit上显示的数字设置为不可更改
    ui->textEdit->setReadOnly(true);

    //初始时为0
    ui->textEdit->setText("0");

    //将str初始化为“#”
    //用于需要一个字符与接下来第一个进入的字符做优先级比较
    str='#';



    //以下第一个pushButtonxxx为信号，第二个指槽函数
    //为方便查找所以将信号和槽设置为同名
    //ui->pushButton_0 表示信号发送者
    //&QpushButton：：clicked表示行为，也就是当产生click的行为后发送信号
    //[this]表示信号是传给本身的，随后那个指的是产生的效果，也就是点击产生的槽函数的调用。


    //绑定按键0与处理函数
    connect(ui->pushButton0,&QPushButton::clicked,[this](){pushButton0();});

    //绑定按键1与处理函数
    connect(ui->pushButton1,&QPushButton::clicked,[this](){pushButton1();});

    //绑定按键2与处理函数
    connect(ui->pushButton2,&QPushButton::clicked,[this](){pushButton2();});

    //绑定按键3与处理函数
    connect(ui->pushButton3,&QPushButton::clicked,[this](){pushButton3();});

    //绑定按键4与处理函数
    connect(ui->pushButton4,&QPushButton::clicked,[this](){pushButton4();});

    //绑定按键5与处理函数
    connect(ui->pushButton5,&QPushButton::clicked,[this](){pushButton5();});

    //绑定按键6与处理函数
    connect(ui->pushButton6,&QPushButton::clicked,[this](){pushButton6();});

    //绑定按键7与处理函数
    connect(ui->pushButton7,&QPushButton::clicked,[this](){pushButton7();});

    //绑定按键8与处理函数
    connect(ui->pushButton8,&QPushButton::clicked,[this](){pushButton8();});

    //绑定按键9与处理函数
    connect(ui->pushButton9,&QPushButton::clicked,[this](){pushButton9();});

    //绑定按键+与处理函数
    connect(ui->pushButton_add,&QPushButton::clicked,[this](){pushButton_add();});

    //绑定按键-与处理函数
    connect(ui->pushButton_sub,&QPushButton::clicked,[this](){pushButton_sub();});

    //绑定按键*与处理函数
    connect(ui->pushButton_mul,&QPushButton::clicked,[this](){pushButton_mul();});

    //绑定按键/与处理函数
    connect(ui->pushButton_div,&QPushButton::clicked,[this](){pushButton_div();});

    //绑定按键=与处理函数
    connect(ui->pushButton_equ,&QPushButton::clicked,[this](){pushButton_equ();});

    //绑定按键"("与处理函数
    connect(ui->pushButton_low_l,&QPushButton::clicked,[this](){pushButton_low_l();});

    //绑定按键")"与处理函数
    connect(ui->pushButton_low_r,&QPushButton::clicked,[this](){pushButton_low_r();});

    //绑定按键"["与处理函数
    connect(ui->pushButton_mid_l,&QPushButton::clicked,[this](){pushButton_mid_l();});

    //绑定按键"]"与处理函数
    connect(ui->pushButton_mid_r,&QPushButton::clicked,[this](){pushButton_mid_r();});

    //绑定按键turn off与处理函数
    connect(ui->pushButton_turn_off,&QPushButton::clicked,[this](){pushButton_turn_off();});

    //绑定按键AC与处理函数
    connect(ui->pushButton_AC,&QPushButton::clicked,[this](){pushButton_AC();});

    //绑定按键Del与处理函数
    connect(ui->pushButton_Del,&QPushButton::clicked,[this](){pushButton_Del();});

    connect(ui->pushButton_Pre,&QPushButton::clicked,[this](){pushButton_Pre();});

    connect(ui->pushButton_In,&QPushButton::clicked,[this](){pushButton_In();});
    connect(ui->pushButton_Post,&QPushButton::clicked,[this](){pushButton_Post();});

    //产生时间的代码
    QTimer *timer = new QTimer(this);

    connect(timer,SIGNAL(timeout()),this,SLOT(timerUpdate()));

    timer->start(1000);

}

//右对齐函数
void myWidget::on_actionRight_triggered()
{
    ui->textEdit->setAlignment(Qt::AlignRight);
}


//时间函数
void myWidget::timerUpdate(void)
{

    QDateTime time = QDateTime::currentDateTime();

    QString str = time.toString("yyyy-MM-dd hh:mm:ss dddd");

    ui->label->setText(str);

    QFont textEditFont ( "Microsoft YaHei", 15, 30);//字体

    ui->label->setFont(textEditFont);
}

//槽函数的编写

void myWidget::pushButton0()
{
    if(str=="#")    ui->textEdit->clear(); //如果strin==“#”，就将textEdit清空
                                           //摁下等于号之后textEdit会显示结果，然后要将strin初始化为#便于下一步运算

       bracket_digit_error1();//判断数字前是否是括号,若是括号则弹出错误信息
       bracket_digit_error2();
        str+="0";

        on_actionRight_triggered();

        ui->textEdit->textCursor().insertText("0");//将0显示出来
}


void myWidget::pushButton1()
{
    if(str=="#")    ui->textEdit->clear();

       bracket_digit_error1();
       bracket_digit_error2();
        str+="1";

        on_actionRight_triggered();

        ui->textEdit->textCursor().insertText("1");
}

void myWidget::pushButton2()
{
    if(str=="#")    ui->textEdit->clear();

       bracket_digit_error1();
       bracket_digit_error2();
        str+="2";

        on_actionRight_triggered();

        ui->textEdit->textCursor().insertText("2");
}

void myWidget::pushButton3()
{
    if(str=="#")    ui->textEdit->clear();

       bracket_digit_error1();
       bracket_digit_error2();
        str+="3";

        on_actionRight_triggered();

        ui->textEdit->textCursor().insertText("3");
}

void myWidget::pushButton4()
{
    if(str=="#")    ui->textEdit->clear();

       bracket_digit_error1();
       bracket_digit_error2();
        str+="4";

        on_actionRight_triggered();

        ui->textEdit->textCursor().insertText("4");
}

void myWidget::pushButton5()
{
    if(str=="#")    ui->textEdit->clear();

       bracket_digit_error1();
       bracket_digit_error2();
        str+="5";

        on_actionRight_triggered();

        ui->textEdit->textCursor().insertText("5");
}

void myWidget::pushButton6()
{
    if(str=="#")    ui->textEdit->clear();

       bracket_digit_error1();
       bracket_digit_error2();
        str+="6";

        on_actionRight_triggered();

        ui->textEdit->textCursor().insertText("6");
}


void myWidget::pushButton7()
{
    if(str=="#")    ui->textEdit->clear();

       bracket_digit_error1();
       bracket_digit_error2();
        str+="7";

        on_actionRight_triggered();

        ui->textEdit->textCursor().insertText("7");
}

void myWidget::pushButton8()
{
    if(str=="#")    ui->textEdit->clear();

       bracket_digit_error1();
       bracket_digit_error2();
        str+="8";

        on_actionRight_triggered();

        ui->textEdit->textCursor().insertText("8");
}

void myWidget::pushButton9()
{
    if(str=="#")    ui->textEdit->clear();

       bracket_digit_error1();
       bracket_digit_error2();
        str+="9";

        on_actionRight_triggered();

        ui->textEdit->textCursor().insertText("9");
}

void myWidget::pushButton_low_l()//左小括号槽函数编写

{

  if(str=="#")    ui->textEdit->clear();

      char*s=str.toLocal8Bit().data();//定义一个char*类型变量s，将str转化

      digit_bracket_error1();//判断之前是否为数字，若为数字则弹出错误信息
      digit_bracket_error2();
      str+="(";

      on_actionRight_triggered();

      ui->textEdit->textCursor().insertText("(");

}

void myWidget::pushButton_mid_l()//左中括号槽函数编写

{

  if(str=="#")    ui->textEdit->clear();

      char*s=str.toLocal8Bit().data();//定义一个char*类型变量s，将str转化

      digit_bracket_error1();
      digit_bracket_error2();
      str+="[";

      on_actionRight_triggered();

      ui->textEdit->textCursor().insertText("[");

}

void myWidget::pushButton_low_r()

{



    if(str=="#")

        ui->textEdit->clear();

    if(!bracket_error1())//检查左括号，左括号缺失

    {

        QMessageBox::about(this,"输入错误","请检查一下左括号数量");//错误提示框

        //这一步要包含QmessageBox头文件，指的是，如果出现这样的错误，    //会弹出弹窗弹窗标题为“输入错误”，内容为“请检查左括号数量”

        digit_bracket_error1();//判错函数,判断之前是否为数字，若为数字弹出报错信息
        digit_bracket_error2();
        str+="(";

        on_actionRight_triggered();//对齐

        ui->textEdit->textCursor().insertText("(");//补齐缺失的左括号

    }

    else//正常输入，无错误的情况

    {

        char*s=str.toLocal8Bit().data();//转化为char*

        if(s[strlen(s)-1]=='(')//如果‘)’前一个是‘（’，证明括号里什么也没有,需要提示并补充个1.

        {

            QMessageBox::about(this,"输入错误","括号里面没有计算或者数字");

            str+="1";

           ui->textEdit->textCursor().insertText("1");

        }

        str+=")";//一切正常的话，则将‘）’加入strin

        on_actionRight_triggered();

      ui->textEdit->textCursor().insertText(")");

    }



}


void myWidget::pushButton_mid_r()

{



    if(str=="#")

        ui->textEdit->clear();

    if(!bracket_error2())//检查左括号，左括号缺失

    {

        QMessageBox::about(this,"输入错误","请检查一下左括号数量");

        //这一步要包含QmessageBox头文件，指的是，如果出现这样的错误，    //会弹出弹窗弹窗标题为“输入错误”，内容为“请检查左括号数量”

        digit_bracket_error1();//判错函数
        digit_bracket_error2();
        str+="[";

        on_actionRight_triggered();//对齐

        ui->textEdit->textCursor().insertText("[");//补齐缺失的左括号

    }

    else//正常输入，无错误的情况

    {

        char*s=str.toLocal8Bit().data();//转化为char*

        if(s[strlen(s)-1]=='[')//如果‘]’前一个是‘[’，证明括号里什么也没有,需要提示并补充个1.

        {

            QMessageBox::about(this,"输入错误","括号里面没有计算或者数字");

            str+="1";

           ui->textEdit->textCursor().insertText("1");

        }

        str+="]";//一切正常的话，则将‘]’加入strin

        on_actionRight_triggered();

      ui->textEdit->textCursor().insertText("]");

    }

}

void myWidget::pushButton_add()

{

  str+="+";

  ui->textEdit->textCursor().insertText("+");

  on_actionRight_triggered();

  operror1();

}

void myWidget::pushButton_sub()

{

  str+="-";

  ui->textEdit->textCursor().insertText("-");

  on_actionRight_triggered();

  operror1();

}

void myWidget::pushButton_mul()

{

  str+="*";

  ui->textEdit->textCursor().insertText("*");

  on_actionRight_triggered();

  operror1();

}

void myWidget::pushButton_div()

{

  str+="/";

  ui->textEdit->textCursor().insertText("/");

  on_actionRight_triggered();

  operror1();

}

void myWidget::pushButton_turn_off()
{
    close();
}

void myWidget::pushButton_AC()

{

    str="#";

    ui->textEdit->setText("0");

    on_actionRight_triggered();

}

void myWidget::pushButton_Del()

{

    str.chop(1);

    ui->textEdit->textCursor().deletePreviousChar();

    if(str=="#")ui->textEdit->setText("0");
    on_actionRight_triggered();
}

void myWidget::pushButton_equ()
{

    if(str=="#")
        {
           QMessageBox::about(this,"Error","不可以直接输出等号");

        }
    double x=Do();
    QString rnt=QString::number(x);

    ui->textEdit->clear();
    on_actionRight_triggered();
    ui->textEdit->textCursor().insertText(rnt);
    str="#";

}

void myWidget::pushButton_Pre()
{
    ui->textEdit->clear();

    LinkStack expt;
    InitStack(expt);	//初始化expt栈(根结点)
    LinkStack optr;
    InitStack(optr);	//初始化optr栈(运算符)
    InitExpTree(expt, optr);	//构建表达式树
    Pop_tree(expt, T);	//获取最后建好的二叉树
    PreOrder(T);
}

void myWidget::pushButton_In()
{
    ui->textEdit->clear();

    LinkStack expt;
    InitStack(expt);	//初始化expt栈(根结点)
    LinkStack optr;
    InitStack(optr);	//初始化optr栈(运算符)
    InitExpTree(expt, optr);	//构建表达式树
    Pop_tree(expt, T);	//获取最后建好的二叉树

    InOrder(T);
}


void myWidget::pushButton_Post()
{
    ui->textEdit->clear();

    LinkStack expt;
    InitStack(expt);	//初始化expt栈(根结点)
    LinkStack optr;
    InitStack(optr);	//初始化optr栈(运算符)
    InitExpTree(expt, optr);	//构建表达式树
    Pop_tree(expt, T);	//获取最后建好的二叉树

    PostOrder(T);
}


//判错函数

//输入了一个运算符号，如果它前面一个符号不是数字也不是右括号，进行错误处理
void myWidget::operror1(int num)

{

    char*s=str.toLocal8Bit().data();//将QString转化为char*

    if(!isdigit(s[strlen(s)-2])&&s[strlen(s)-2]!=')'&&s[strlen(s)-2]!=']')//不是数字或右括号

    {

        QMessageBox::about(this,"输入有误","您输入的双目运算符无左值");

        str.chop(1);//从字符串的末尾去掉一个字符

        for(int i=1;i<=num;i++)//从屏幕删去

            ui->textEdit->textCursor().deletePreviousChar();



    }

}


//看括号的个数是否对应
int myWidget::bracket_error1()

{

    int l=0,r=0;

    for(int i=0;i<str.size();i++)

    {

        if(str[i]=='(')l++;

        if(str[i]==')')r++;

    }

    return l-r;

}

int myWidget::bracket_error2()

{

    int l=0,r=0;

    for(int i=0;i<str.size();i++)

    {

        if(str[i]=='[')l++;

        if(str[i]==']')r++;

    }

    return l-r;

}



//左括号前是数字时弹出错误信息
void myWidget::digit_bracket_error1()

{

    char*s=str.toLocal8Bit().data();

       if(isdigit(s[strlen(s)-1])||s[strlen(s)-1]==')')

       {

           QMessageBox::about(this,"输入有误","您要输入的左括号前是数");

           str+="*";

           ui->textEdit->textCursor().insertText("*");

       }

}

void myWidget::digit_bracket_error2()

{

    char*s=str.toLocal8Bit().data();

       if(isdigit(s[strlen(s)-1])||s[strlen(s)-1]==']')

       {

           QMessageBox::about(this,"输入有误","您要输入的左括号前是数");

           str+="*";

           ui->textEdit->textCursor().insertText("*");

       }

}



//要输入的数字前是右括号
void myWidget::bracket_digit_error1()

{

    char* s=str.toLocal8Bit().data();

        if(s[strlen(s)-1]==')')

        {

            QMessageBox::about(this,"输入有误","您要输入的数字前是右括号");

            str+="*";

            ui->textEdit->textCursor().insertText("*");



        }
}

void myWidget::bracket_digit_error2()

{

    char* s=str.toLocal8Bit().data();

        if(s[strlen(s)-1]==']')

        {

            QMessageBox::about(this,"输入有误","您要输入的数字前是右括号");

            str+="*";

            ui->textEdit->textCursor().insertText("*");



        }
}
//计算部分

double myWidget:: Do()
{
    QStack<char> string;
    QStack<double> num;
    char*s=str.toLocal8Bit().data();
        string.push('#');//字符串栈第一个放入#
        int len=strlen(s);
    s[len] = '#';//字符串最后一个放入#,便于之后符号比较优先级

    for (int i = 1; i <= len; i++)//从0开始对输入的表达式进行循环检查
    {
        there:
        long double n = 0;
        if (is_num(s[i]))//判断是否为数字
        {
            n = (long double)(s[i] - '0');//将数字赋给n
            while (is_num(s[i + 1]))//如果下个字符仍是数字，则说明输入的是十位以上的数，应另外计算
            {
                n = 10 * n + (long double)(s[i + 1]-'0');//每判断一次就加一次
                i++;//注意i应该加一，避免循环时重复
            }

            num.push(n);//将得到的最终数字存入数字栈
        }


        if(s[i] == '[')//判断左括号
        {
           string.push(s[i]);
        }

        else if(s[i] == ']')
        {

            if (string.top() == '[')//如果前一个符号是'['，则应该都释放
                string.pop();

            else
            {
                char top = ' ';
                top=string.top();
                if (top != '#')
                {
                    double l1 = 0;
                    l1 = num.top();//取栈顶数字
                    num.pop();//释放
                    double l2 = 0;
                    l2 = num.top();//取当前栈顶数字
                    num.pop();//释放
                    num.push(Cal(l1, string.top(), l2));//计算
                    string.pop();//将字符栈当前栈顶符号释放
                    char s4 = '0';
                    s4 = string.top();
                    if (s4 == '[')//如果释放之后发现'['与']'相邻
                        string.pop();//则释放'['
                    else
                        goto there;
                }
            }





        }







         if (s[i] == '(')//判断左括号
        {
            string.push(s[i]);

        }

        else if (s[i] == ')')
        {
            if (string.top() == '(')//如果前一个符号是'('，则应该都释放
                string.pop();

            else
            {
                char top = ' ';
                top=string.top();
                if (top != '#')
                {
                    double l1 = 0;
                    l1 = num.top();//取栈顶数字
                    num.pop();//释放
                    double l2 = 0;
                    l2 = num.top();//取当前栈顶数字
                    num.pop();//释放
                    num.push(Cal(l1, string.top(), l2));//计算
                    string.pop();//将字符栈当前栈顶符号释放
                    char s4 = '0';
                    s4 = string.top();
                    if (s4 == '(')//如果释放之后发现'('与')'相邻
                        string.pop();//则释放'('
                    else
                        goto there;
                }
            }
        }

        else if (s[i] == '+' || s[i] == '-')
        {
            char s3 = string.top();

            if (prior(s[i]) > prior(s3))//如果当前字符优先级大于栈顶字符优先级
            {
                string.push(s[i]);
                //当前字符入栈
            }

            else//不然则需进行计算，流程同上
            {
                char top = ' ';
                top=string.top();
                if (top != '#')
                {
                    double l1 = 0;
                    l1=num.top();
                    num.pop();
                    double l2 = 0;
                    l2=num.top();
                    num.pop();
                    num.push(Cal(l1, string.top(), l2));
                    string.pop();

                    char s4 = 'a';
                    s4 = string.top();
                    if (prior(s[i]) > prior(s4))//如果当前字符优先级大于栈顶字符优先级
                    {

                        string.push(s[i]);
                        //当前字符入栈
                    }
                    else
                        goto there;
                }
            }
        }
        else if (s[i] == '*' || s[i] == '/')
        {
            char s3 = ' ';
            s3=string.top();
            if (prior(s[i]) > prior(s3))
            {
                string.push(s[i]);
            }
            else
            {
                char top = ' ';
                top=string.top();
                if (top != '#')
                {
                    double l1 = 0;
                    l1=num.top();
                    num.pop();
                    double l2 = 0;
                    l2=num.top();
                    num.pop();
                    num.push(Cal(l1, string.top(), l2));
                    string.pop();
                    string.push(s[i]);
                }
            }

        }
        else if (s[i] == '#')
        {
            if (prior(s[i]) > prior(string.top()))
                string.push(s[i]);
            else
            {
                char top=string.top();
                    if (top != '#')
                    {
                       double l1 = num.top();
                        num.pop();
                        double l2 = num.top();
                        num.pop();
                        num.push(Cal(l1, top, l2));
                        string.pop();
                        if (string.top() == '#')
                            string.pop();
                        else
                            goto there;//还需继续计算，回到最初判断点
                    }

            }

        }




    }
    double end=num.top();
    return end;
}



int myWidget::prior(char c)
{
    switch (c)
    {
    case '#': return 0;
    case '[': case ']': return 1;
    case '(': case ')': return 2;
    case '-': case '+': return 3;
    case '*': case '/': return 4;
    }

}



bool myWidget:: is_num(char s)
{
    return s >= '0' && s <= '9';
}


double myWidget::Cal(double a, char b, double c)
{
    switch (b)
    {
    case '+':return a + c;
    case '-':return c - a;
    case '*':return a * c;
    case '/':return c / a;
    }
}

//栈的初始化
int myWidget::InitStack(LinkStack &S)
{
    S = NULL;
    return 1;
}
//二叉树入栈
int myWidget::Push_tree(LinkStack &S, BiTree e)
{
    LinkStack p = new StackNode;
    p->data_tree = e;
    p->next = S;
    S = p;
    return 1;
}
//字符（运算符号）入栈
int myWidget::Push_op(LinkStack &S, QChar e)
{
    LinkStack p = new StackNode;
    p->data_op = e;
    p->next = S;
    S = p;
    return 1;
}
//二叉树出栈
int myWidget::Pop_tree(LinkStack &S, BiTree &T1)
{
    if (S == NULL)	return 0;
    LinkStack p = S;
    T1 = p->data_tree;
    S = S->next;
    delete p;
    return 1;
}
//字符（运算符号）出栈
int myWidget::Pop_op(LinkStack &S, QChar &ch)
{
    if (S == NULL)	return 0;
    LinkStack p = S;
    ch = p->data_op;
    S = S->next;
    delete p;
    return 1;
}

//取栈顶元素
QChar myWidget::GetTop_op(LinkStack S)
{
    if (S != NULL)	return S->data_op;
    else return ' ';
}
BiTree myWidget::GetTop_tree(LinkStack S)
{
    if (S != NULL)	return S->data_tree;
    else return NULL;
}

//创建以T为根结点的二叉树
void myWidget::CreateExpTree(BiTree &T, BiTree a, BiTree b, QChar theta)//a是左孩子，b是右孩子,theta是数据域
{
    BiTree L = new BiTNode;
    L->data = theta;
    L->lchild = a;
    L->rchild = b;
    T = L;
}

void myWidget::CreateExpTree_str(BiTree &T, BiTree a, BiTree b, QString theta)
{
    BiTree L = new BiTNode;
    L->combine_data = theta;
    L->lchild = a;
    L->rchild = b;
    T = L;
}

//比较运算符的优先级
//top是栈顶元素，ch是需要比较的元素
char myWidget::Precede(QChar top, QChar ch)
{
    if (ch == ']'&&top == '[')	return '=';

    else if (ch == ']')	return '>';

    if (ch == ')'&&top == '(')	return '=';

    else if (ch == ')')	return '>';

    if (top == ' ' || top == '[' || ch == '[') return '<';

    if (top == ' ' || top == '(' || ch == '(') return '<';

    if (ch == '#')	return '>';

    if (top == '+' || top == '-')
    {
        if (ch == '+' || ch == '-')    return '>';

        else if (ch == '/' || ch == '*')	return '<';
    }

    else if (top == '*' || top == '/')    return '>';
}

//创建表达式树
//expt栈(根结点)，optr栈(运算符)
void myWidget:: InitExpTree(LinkStack &expt, LinkStack &optr)
{
    char*ep=str.toLocal8Bit().data();

    int n = strlen(ep);
    ep[n] = '#';
    int i = 1;
    BiTree T = NULL;	//树根
    BiTree T1 = NULL;	//左子树
    BiTree T2 = NULL;	//右子树
    QChar ch = ' ';	//弹出的符号
    QString combine_str = "";	//存储数值，可大于9
    while (i != n+1)
    {
        if (ep[i] >= '0' && ep[i] <= '9') {		//数值（二叉树），进入expt栈中
            combine_str += ep[i];
            if (ep[i + 1] >= '0' && ep[i + 1] <= '9') {	//下一位仍是数字，需连接
                i++;
                continue;
            }
            CreateExpTree_str(T, NULL, NULL, combine_str);
            combine_str = "";	//建完数值的二叉树后string要置空
            Push_tree(expt, T);
            i++;
        }
        else {
            switch (Precede(GetTop_op(optr),ep[i]))		//比较优先级
            {
            case '<':
                Push_op(optr, ep[i]);
                i++;
                break;
            case '>':
                Pop_op(optr, ch);	//弹出上一个字符
                Pop_tree(expt, T1);	//弹出上两个数值（二叉树）
                Pop_tree(expt, T2);
                CreateExpTree(T, T2, T1, ch);	//以data_tree为根，连接T1和T2两颗子树
                Push_tree(expt, T);		//最后把T放进expt栈中
                break;
            case '=':
                Pop_op(optr, ch);
                i++;
                break;
            default:
                break;
            }
        }
    }
}


//树的遍历

void myWidget::PreOrder(BiTree T)//前序遍历
{
    if (T)
    {
        if (T->lchild == NULL&&T->rchild == NULL) {
             ui->textEdit->textCursor().insertText(T->combine_data);
             ui->textEdit->textCursor().insertText(" ");
        }
        else
        {
            ui->textEdit->textCursor().insertText(T->data);
            ui->textEdit->textCursor().insertText(" ");
        }
        PreOrder(T->lchild);
        PreOrder(T->rchild);
    }
}

//中序遍历
void myWidget::InOrder(BiTree T)
{
    if (T)
    {
        InOrder(T->lchild);
        if (T->lchild == NULL&&T->rchild == NULL) {
            ui->textEdit->textCursor().insertText(T->combine_data);
            ui->textEdit->textCursor().insertText(" ");
        }
        else
        {
            ui->textEdit->textCursor().insertText(T->data);
            ui->textEdit->textCursor().insertText(" ");
        }
        InOrder(T->rchild);
    }
}

//表达式树的后序遍历
void myWidget::PostOrder(BiTree T)
{
    if (T)
    {
        PostOrder(T->lchild);
        PostOrder(T->rchild);
        if (T->lchild == NULL&&T->rchild == NULL) {
            ui->textEdit->textCursor().insertText(T->combine_data);
            ui->textEdit->textCursor().insertText(" ");
        }
        else
        {
            ui->textEdit->textCursor().insertText(T->data);
            ui->textEdit->textCursor().insertText(" ");
        }

    }
}





myWidget::~myWidget()
{
    delete ui;
}

